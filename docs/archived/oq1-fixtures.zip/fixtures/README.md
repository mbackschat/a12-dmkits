# OQ1 probe fixtures

Starting models for the **dmcode vs bare-tool-CLI** probe (OQ1). Full analysis: `docs/archived/OQ1-INVESTIGATION.md`; verdict: `eval/RESULTS.md` (2026-06-17 03:03). All own-domain (insurance / e-commerce), kernel-valid (authored via `dmtool`). During the probe the agents worked on **copies**; these are the originals.

| fixture | model | task | gold / oracle |
|---|---|---|---|
| `C1.dm.json` | insurance policy (`PolicyHolder`, `BaseLimit`) | bulk-5: add 5 `<Tier>Limit` fields + >0-when-present rules | valid + 5 `*Limit` fields + 5 rules |
| `C2.dm.json` | order: `Quantity/Weight/DiscountAmount/Subtotal` + rules `WEIGHT_MIN` & `DISCOUNT_MAX` (unguarded), `QTY_MIN` (guarded) | guard the unguarded numeric comparisons | guard `{WEIGHT_MIN, DISCOUNT_MAX}`, leave `QTY_MIN` (the `RK_UNGUARDED_NUMBER_COMPARISON` lint is the oracle; note the field-vs-field `DISCOUNT_MAX` is *not* flagged — the C2 ambiguity) |
| `C3.dm.json` | order: `LegacyOrderId`, `LegacyCustomerRef`, `OrderDate`, `Total` + 2 rules | bulk rename: drop the `Legacy` prefix, rewrite refs | `LegacyOrderId→OrderId`, `LegacyCustomerRef→CustomerRef`, valid |
| `C4.dm.json` | order: `CustomerName/OrderDate/Total/Quantity/Notes` + `TOTAL_VS_QTY`, `DATE_REQ` | reference-map base (reused as D) | `Total→TOTAL_VS_QTY`, `Quantity→TOTAL_VS_QTY`, `OrderDate→DATE_REQ`, `CustomerName`/`Notes`→none |
| `A.dm.json` | order: 6 fields incl. `ShipCity` + 1 deliberately-long-message rule | aggregate audit → JSON `{unreferencedFields, longMessageRules>60}` | unreferenced `= {CustomerName, Notes, ShipCity}`; long-msg `= {TOTAL_VS_QTY}` |
| `C.dm.json` + `C-spec.json` | order base (`PolicyNumber`) + 25-item coverage spec | data-driven ×25: a `<Item>Fee` field + >0 rule per spec item | +25 `*Fee` fields + 25 rules, valid |
| `D.dm.json` | = `C4`'s model | state-parameterized: each field's internal description = its constraining rule codes | each desc = `Constrained by: <where-used codes \| none>` |
| `E-ws/` (`orderA/B/C.dm.json`) | 3 order models, each `CustomerId`(STRING) + `Amount`(NUMBER) + rule `CUSTID_REQ` | multi-model rename across the workspace | all 3: `CustomerId→AccountId` + refs rewritten, valid |

## Re-running the probe

Copy a fixture, give the **neutral intent** (the verbatim `TASK:` lines + the per-arm prompt templates are in `OQ1-INVESTIGATION.md` §2/§2a — state the requirement only, never the technique), then run:

- **CLI arm** — only `dmtool` + the model copy (bare-tool boundary; never read/write the raw `.dm.json` directly — use the read verbs).
- **Code-mode arm** — only the API reference + the model copy; source-launch Java against the kits classpath (`java -cp '<…>/cli/build/install/dmtool/lib/*' App.java`). The code-arm material was `api.txt` (a scoped signature+javadoc dump of the kit packages — **regenerable**, not stored here) + `operators.json` (= `src/main/resources/catalog/operators.json`).

Score deterministically against the golds above; never trust self-reports. Boundary discipline + the validity audit: `OQ1-INVESTIGATION.md` §9.
